# Active IndustrialPlanner Single-Base Entrypoints

- Release id: `valley4_protocol_core_70x70_r20260416`
- Base id: `valley4_protocol_core`
- Lot size: `70`
- Delivery status: `ready_for_single_base_delivery`
- Exact full-scale CERTIFIED status: `open`
- Exact note: The full-scale 70×70 exact `CERTIFIED` end-state is still an open item. This workflow validates the current single-base delivery bundle and checked-in support surfaces only; it does not claim that the full exact terminal proof artifact has already been checked in.
- Scope note: Current release scope is intentionally limited to the active IndustrialPlanner contract `valley4_protocol_core` (70×70). Other bases and the outer-deployment path remain preserved as `future_scope` and are not widened by this release builder.

## Shortest current actions

- Repo frontdoor HTML: `data/examples/industrial_planner/index.html`
- Current delivery HTML: `data/examples/industrial_planner/current_delivery/index.html`
- Current viewer HTML: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/index.html`
- Latest bundle ZIP: `data/examples/industrial_planner/industrial_planner_latest_single_base_delivery_bundle.zip`
- Current bundle ZIP: `data/examples/industrial_planner/current_delivery/downloads/industrial_planner_current_single_base_delivery_bundle.zip`
- Release pointer JSON: `data/examples/industrial_planner/active_single_base_delivery_release.json`
- Viewer pointer JSON: `data/examples/industrial_planner/active_single_base_delivery_viewer.json`
- This entrypoints JSON: `data/examples/industrial_planner/active_single_base_delivery_entrypoints.json`

## Current entrypoint groups

### Release

- pointer_json: `data/examples/industrial_planner/active_single_base_delivery_release.json`
- pointer_markdown: `data/examples/industrial_planner/active_single_base_delivery_release.md`
- release_dir: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416`
- release_manifest_json: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/release_manifest.json`
- release_manifest_markdown: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/release_manifest.md`
- blueprint: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/bundle/industrial_planner.blueprint.json`
- compatibility_manifest: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/bundle/industrial_planner.compatibility_manifest.json`
- validation_report: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/bundle/validation_report.json`
- throughput_report: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/bundle/throughput_report.json`
- run_summary: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/run_summary.json`
- sha256sums: `data/examples/industrial_planner/releases/valley4_protocol_core_70x70_r20260416/SHA256SUMS.txt`

### Viewer

- pointer_json: `data/examples/industrial_planner/active_single_base_delivery_viewer.json`
- pointer_markdown: `data/examples/industrial_planner/active_single_base_delivery_viewer.md`
- viewer_dir: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416`
- index_html: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/index.html`
- manifest_json: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/release_viewer_manifest.json`
- optimal_blueprint: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/optimal_blueprint.json`
- candidate_placements: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/candidate_placements.json`
- final_solution: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/final_solution.json`
- viewer_report: `data/examples/industrial_planner/viewers/valley4_protocol_core_70x70_r20260416/viewer_report.json`
- selected_facility_type_count: `4`
- selected_pose_count: `273`
- payload_download_count: `24`
- metadata_download_count: `7`
- quick_download_count: `5`

### Landing

- output_dir: `data/examples/industrial_planner/current_delivery`
- index_html: `data/examples/industrial_planner/current_delivery/index.html`
- manifest_json: `data/examples/industrial_planner/current_delivery/landing_manifest.json`
- viewer_dir: `data/examples/industrial_planner/current_delivery/viewer`
- viewer_index_html: `data/examples/industrial_planner/current_delivery/viewer/index.html`
- viewer_manifest_json: `data/examples/industrial_planner/current_delivery/viewer/release_viewer_manifest.json`
- current_bundle_zip: `data/examples/industrial_planner/current_delivery/downloads/industrial_planner_current_single_base_delivery_bundle.zip`
- current_bundle_pointer_json: `data/examples/industrial_planner/current_delivery/downloads/current_single_base_delivery_bundle.json`
- current_bundle_pointer_markdown: `data/examples/industrial_planner/current_delivery/downloads/current_single_base_delivery_bundle.md`
- selected_facility_type_count: `4`
- selected_pose_count: `273`
- payload_download_count: `24`
- metadata_download_count: `7`
- quick_download_count: `5`
- download_group_count: `5`
- current_bundle_archive_sha256: `3a1858e9cbae5f82e472bdef883e2c29e6304a00bc2739816b890fcd3813b59d`
- current_bundle_archive_size_bytes: `52934`
- current_bundle_payload_file_count: `24`
- current_bundle_metadata_file_count: `7`

### Latest Bundle

- bundle_zip: `data/examples/industrial_planner/industrial_planner_latest_single_base_delivery_bundle.zip`
- pointer_json: `data/examples/industrial_planner/latest_single_base_delivery_bundle.json`
- pointer_markdown: `data/examples/industrial_planner/latest_single_base_delivery_bundle.md`
- archive_root: `industrial_planner_current_single_base_delivery_bundle`
- archive_sha256: `3a1858e9cbae5f82e472bdef883e2c29e6304a00bc2739816b890fcd3813b59d`
- archive_size_bytes: `52934`
- payload_file_count: `24`
- metadata_file_count: `7`
- included_entry_count: `31`
- source_current_bundle_zip: `data/examples/industrial_planner/current_delivery/downloads/industrial_planner_current_single_base_delivery_bundle.zip`
- source_current_bundle_pointer_json: `data/examples/industrial_planner/current_delivery/downloads/current_single_base_delivery_bundle.json`
- source_current_bundle_pointer_markdown: `data/examples/industrial_planner/current_delivery/downloads/current_single_base_delivery_bundle.md`

### Surface Alignment

- json: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.json`
- markdown: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.md`
- console: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.txt`
- status: `clean`
- is_clean: `True`
- checked_check_count: `229`
- clean_check_count: `229`
- drift_check_count: `0`
- helper_link_count: `21`
- helper_link_clean_count: `21`
- checked_frontdoor_manifest_json: `data/examples/industrial_planner/frontdoor_manifest.json`
- checked_frontdoor_index_html: `data/examples/industrial_planner/index.html`
- checked_entrypoints_json: `data/examples/industrial_planner/active_single_base_delivery_entrypoints.json`
- checked_entrypoints_markdown: `data/examples/industrial_planner/active_single_base_delivery_entrypoints.md`

### Surface Health

- json: `data/examples/industrial_planner/current_surface_health.json`
- markdown: `data/examples/industrial_planner/current_surface_health.md`
- console: `data/examples/industrial_planner/current_surface_health.txt`
- status: `clean`
- is_clean: `True`
- checked_check_count: `229`
- clean_check_count: `229`
- drift_check_count: `0`
- helper_link_count: `21`
- helper_link_clean_count: `21`
- summary_text: `clean · 229 checks · 0 drift`
- badge_label: `current surface`
- badge_tone: `healthy`
- source_surface_alignment_json: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.json`
- source_surface_alignment_markdown: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.md`
- source_surface_alignment_console: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.txt`
- checked_frontdoor_manifest_json: `data/examples/industrial_planner/frontdoor_manifest.json`
- checked_frontdoor_index_html: `data/examples/industrial_planner/index.html`
- checked_entrypoints_json: `data/examples/industrial_planner/active_single_base_delivery_entrypoints.json`
- checked_entrypoints_markdown: `data/examples/industrial_planner/active_single_base_delivery_entrypoints.md`

## Repo frontdoor

- index_html: `data/examples/industrial_planner/index.html`
- manifest_json: `data/examples/industrial_planner/frontdoor_manifest.json`
- browse_primary_href: `data/examples/industrial_planner/current_delivery/viewer/index.html`
- download_primary_href: `data/examples/industrial_planner/industrial_planner_latest_single_base_delivery_bundle.zip`

## Surface summary

- viewer_selected_facility_type_count: `4`
- viewer_selected_pose_count: `273`
- viewer_payload_download_count: `24`
- viewer_metadata_download_count: `7`
- viewer_quick_download_count: `5`
- landing_quick_download_count: `5`
- landing_download_group_count: `5`
- current_bundle_payload_file_count: `24`
- current_bundle_metadata_file_count: `7`
- current_bundle_archive_size_bytes: `52934`
- latest_bundle_archive_size_bytes: `52934`
- surface_alignment_status: `clean`
- surface_alignment_check_count: `229`
- surface_alignment_drift_check_count: `0`
- surface_health_status: `clean`
- surface_health_check_count: `229`
- surface_health_drift_check_count: `0`
- surface_health_helper_link_count: `21`
- surface_health_helper_link_clean_count: `21`

## Current consumer-surface audit

- JSON: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.json`
- Markdown: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.md`
- Console: `.artifacts/industrial_planner_single_base_delivery_surface_alignment/surface_alignment_summary.txt`
- Status: `clean`
- Checks: `229`
- Drift checks: `0`

## Current surface health snapshot

- JSON: `data/examples/industrial_planner/current_surface_health.json`
- Markdown: `data/examples/industrial_planner/current_surface_health.md`
- Console: `data/examples/industrial_planner/current_surface_health.txt`
- Status: `clean`
- Summary: `clean · 229 checks · 0 drift`
- Checks: `229`
- Drift checks: `0`

## Notes

- Current release scope is intentionally limited to the active IndustrialPlanner contract `valley4_protocol_core` (70×70). Other bases and the outer-deployment path remain preserved as `future_scope` and are not widened by this release builder.
- The full-scale 70×70 exact `CERTIFIED` end-state is still an open item. This workflow validates the current single-base delivery bundle and checked-in support surfaces only; it does not claim that the full exact terminal proof artifact has already been checked in.
- This checked-in manifest exists for script consumers that want one stable file summarizing the active release pointer, viewer pointer, stable current landing bundle, and shorter top-level latest bundle alias.
- Other bases remain preserved as future_scope, and the full-scale exact 70×70 CERTIFIED end-state is still honestly tracked as open.

# code_context/ — review-only source snapshots

This directory contains **read-only source code snapshots** for review
reproducibility per GPT pro v17 四审 Reviewer B patch 0002 spec.

**These files are NOT part of the master merge target.** They live only on
the spike branch (`spike/prod_scale_master_integration_20260526`). They are
included in this review package so reviewers can source-check call sites
that produced the data artifacts in this package.

## spike/

Spike-only Phase B implementation code (11 files in v22):

- `spike_prod_scale_runner.py` — top-level Phase B runner orchestrating
  A2 failfast + A3 oracle emit + B1-B6 phase steps
- `spike_prod_scale_lib/telemetry.py` — `emit_rss_after_solve()` impl
  (relevant for v17 telemetry rss_sample_after_solve raw event class)
- `spike_prod_scale_lib/scale_ramp.py` — `run_one_tier()` impl with
  after-solve emit call site (relevant for telemetry event correctness)
- `spike_prod_scale_lib/oracle_emit_fixture.py` — `_emit_f3` driver +
  `_DRIVERS` registry (relevant for A3 50-cert/9-family fixture)
- `spike_prod_scale_lib/off_limits_check.py` — off-limits enforcement
  harness (no master src writes)
- `spike_prod_scale_lib/failfast_probe.py` — A2 probe impl
- `spike_prod_scale_lib/feasible_smoke.py` — B3 feasible smoke impl
- `spike_prod_scale_lib/filter_mock.py` — B4 active filter mock loop
- `spike_prod_scale_lib/toy_translator.py` — B1 toy translator
  (loose constraints, NOT real PoseBoolExactMaster)
- `spike_prod_scale_lib/test_toy_translator_f3_malformed.py` — **v22 new**.
  F3 malformed cert micro-probe self-test (9 case: 6 F3 malformed +
  3 non-F3 fallback). Locks GPT V21-8F1 fail-closed contract:
  payload decode fail / non-dict root → F3 family return [] (不
  fallback synthesize 3-literal). Run:
  `python scripts/spike_prod_scale_lib/test_toy_translator_f3_malformed.py`
  expect exit 0 + "9/9 PASS".
- `spike_prod_scale_lib/__init__.py` — package marker

## SHA256SUMS.spike_code.txt

SHA256 manifest of all snapshot files for integrity verification.
The manifest paths are relative to this directory, so run from inside
``code_context/``:

```bash
(cd code_context && sha256sum -c SHA256SUMS.spike_code.txt)
```

## Why these are NOT merged to master

Per MERGER §5.1 (rollback-safety, PR #1 verdict-only style): spike
implementation code is intentionally not cherry-picked into master because
the toy translator constraints differ from production
`PoseBoolExactMaster` (ExactlyOne / port-linking / anti-overlap). Spike's
purpose was Sizing Layer-1 measurement (Finding 5 close gate), not
P1.3A 主体 implementation. Production P1.3A walks N=8 parallel design
fresh; cherry-picking spike code would anchor the design on toy
translator choices.

The data artifacts (telemetry / fixture / scale ramp / phase B
aggregate) ARE valid Layer-1 evidence and live in canonical paths
(`data/cuts/spike/`).

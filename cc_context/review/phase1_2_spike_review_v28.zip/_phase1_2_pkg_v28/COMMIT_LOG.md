# Commit log (master line)

本表列出本次 review pkg master 涵盖的 commit 区间 (按时间序). spike branch
commit 列在 `SPIKE_COMMIT_LOG.md`.


| Commit | Subject |
|---|---|
| 7b0c3c8 | R4 apply Phase 1.1 recheck补强 patch (188 cuts pass, fail-closed schema) |
| e32c655 | review-pkg v11 build script (Phase 1.1 R4 recheck补强, 188 pytest) |
| 4278307 | R5 apply Phase 1.1 final polish (189 cuts pass, F3 grid-bound + 命名口径统一) |
| 11f5337 | feat(F5): land Phase 1.2 P1.2B-F5 pattern_nogood family (246 cuts pass) |
| 3d93b1d | fix(F5): Gemini round 1 fix (4 findings landed) |
| ca60a35 | fix(F5): Gemini round 2 fix (4 findings + 2 LOW landed) |
| 9cd676a | fix(F5): Gemini round 3 minor fix |
| f2d8f31 | feat(F9): land Phase 1.2 P1.2B-F9 density_envelope family (278 cuts pass) |
| 515aed4 | fix(F9): Gemini round 1 fix (1 BLOCKER + 2 HIGH landed) |
| e3aa3e9 | fix(F9): Gemini round 2 fix (1 BLOCKER + 1 HIGH landed) |
| 6153ce5 | fix(F9): Gemini round 3 BLOCKER #1 fix |
| 0bed978 | fix(F9): Gemini round 4 REVERT R3 cert_max=0 patch + positive test |
| 92224c4 | feat(F2/F4): land Phase 1.2 P1.2B-F2/F4 generator + Dinic node-split helper |
| 01d368a | fix(F2/F4): Gemini round 1 fix (1 BLOCKER + 1 LOW landed) |
| d5e653d | fix(F4): Gemini round 2 LOW #3 — carry blocking_facilities cert key |
| 180400b | docs(F2/F4): Gemini round 3 close — GO_WITH_MINOR |
| ec16f06 | docs(06_current_status): sound ≠ converge 警句 |
| 6adc5fd | feat(F6): land Phase 1.2 P1.2B-F6 shape_packing_hall (initial) |
| 9fac6d6 | fix(F6): Gemini round 1 fix |
| 97388a0 | fix(F6): Gemini round 2 fix |
| 64cd15f | docs(F6): Gemini round 3 close |
| c30d681 | feat(F7): land Phase 1.2 P1.2B-F7 power_hitting_set (initial) |
| 9f21901 | fix(F7): Gemini round 1 cross-check fixes |
| e5f0e18 | docs(F7): Gemini round 2 close |
| 4be1b60 | feat(F8): land Phase 1.2 P1.2B-F8 power_grid_reach (initial) |
| b9ab24a | fix(F8): Gemini round 1 cross-check |
| fe7c239 | fix(F8): Gemini round 2 cross-check |
| 29b64d0 | fix(F8): Gemini round 3 cross-check |
| 3b9c8b3 | fix(F8): Gemini round 4 cross-check |
| 4721c04 | docs(F8): Gemini round 5 close |
| 3f1c581 | feat(P1.2): mini Step 8 spike — 6 family CP-SAT translator + 10K cost |
| 5b49f04 | docs(F5/F9): archive Gemini cross-check round raw transcripts |
| 9127c60 | docs(research): archive paradigm v12 review + literature review packages |
| 983ee65 | docs(research): backfill real-measure data for cand_c/smt_mt/sac_hull trials |
| cb8e347 | chore(F7 test): rename unused _kwargs param to clear vulture warning |
| ca10fb0 | review-pkg v12 build script |
| 438f1c9 | review-pkg v12: 重写 README + COMMIT_LOG 清主动性内容 |
| 68fa7f0 | fix(cuts): bind F7/F8 validator to candidate_placements pose registry (audit BLOCKER ×2) |
| a3414ee | fix(cuts): drop stale state.source_digest fallback in 7 oracles (audit HIGH) |
| 035bd21 | docs: archive Phase 1.2 GPT pro audit + fix lifecycle line ref (audit LOW) — v13 build state |
| 45c7a25 | research(spike): prod-scale spike design 8 路 parallel + main merger |
| 52cd014 | research(spike): MERGER round 1 fix per Gemini cross-check |
| 3523526 | research(spike): MERGER round 2 fix per Gemini cross-check |
| b44d0c6 | research(spike): MERGER shrink §5 scope per user scope creep audit |
| f7b88b6 | research(spike): MERGER round 3 fix (G6 + G11 + Q8 文档化) — v14 build state |
| d575a87 | fix(review-pkg v14): replace non-existent scale_ramp_test_smoke.jsonl with phase_b_results.json |
| 832f157 | fix(audit-repro): add sys.path bootstrap + correct shell repro path per GPT pro v14 二审 |
| 3ad3de5 | review-pkg v14 build script — spike close gate snapshot |
| 6abe992 | review-pkg v15 build script — GPT pro v14 二审 fix |
| 5e05ef6 | fix(review-pkg v15): strip verdict-claim priming from README per review-pkg-no-prompt-inside |
| b3c370e | fix(audit-repro): harden project root discovery via PROJECT_LOCK.md walk-up |
| f17f13e | fix(F8): streaming reachability replaces full power graph materialization |
| 3b0cc76 | review-pkg v16 build script — GPT pro v15 三审 fix |
| c768806 | feat(F3): implement port_exposure generator per spec §5 (special-case phase stage 1) |
| b5860bc | fix(F3): Gemini round 1 — add logging.debug to silent skip paths |
| 3dbfa39 | review-pkg v17 build script — F3 special-case phase close |
| c639063 | fix(F3): self-blocker defensive guard per GPT v17 四审 Reviewer B NIT |
| 8cc6780 | docs(F3): archive Gemini cross-check round 1+2 transcript per GPT v17 四审 Reviewer A M3 |
| 9d5d7fa | docs(P1.5+): document F3 active_port_witness production-前置 risk per GPT v17 四审 Reviewer A M1 |
| 88735ad | review-pkg v18 build script — GPT v17 四审 MINOR 全 fix |
| 580eb93 | review-pkg v19 build script — GPT v18 五审 evidence + manifest fix |
| f255794 | review-pkg v20 build script — GPT v19 六审 semantics + doclag fix |
| d342784 | refactor(F9): split generate_density_envelope_cuts to fix radon D(27) → B(10) |
| e032f9e | review-pkg v21 build script — v20 七审 union fix |
| 5d214f4 | fix(gate-script): exit_criteria use sys.executable + F7/F8/F9 real test names |
| (v22 build) | review-pkg v22 build script — GPT 八审 V21-8F1 MED + 2 NIT fix |
| (v23–v28) | 后续五轮外审 B 全修 (build 脚本 v23–v28 + spike 分支): bitset LSB / bytes-by-kind / concrete-literal / F9 single-group→single-grp / writer risk#6 / doc currency。详 SPIKE_COMMIT_LOG.md + git log |
| 39c80c6 | fix(F7 soundness): power_hitting_set 验 pole_radius vs canonical SoT (内部严格审第3轮 HIGH, 镜像 F8, cuts 418) |
